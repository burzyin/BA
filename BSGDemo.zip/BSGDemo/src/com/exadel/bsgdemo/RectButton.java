package com.exadel.bsgdemo;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.Button;

public class RectButton extends Button{

	public RectButton(Context context, AttributeSet attrs) {
		super(context, attrs);
	}
	@Override
	protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
		super.onMeasure(widthMeasureSpec, heightMeasureSpec);
		int width = getMeasuredWidth();
		int height = getMeasuredHeight();
		//setMeasuredDimension(heightMeasureSpec, heightMeasureSpec);
		setMeasuredDimension(height, height);
	}

}
