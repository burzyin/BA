package com.exadel.bsgdemo.near;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Environment;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.CursorLoader;
import android.support.v4.content.Loader;
import android.support.v4.widget.CursorAdapter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.exadel.bsgdemo.MediaContentProvider;
import com.exadel.bsgdemo.R;
import com.exadel.bsgdemo.data.Place;
import com.exadel.bsgdemo.place.PlaceDescriptionActivity;

public class NearListFragment extends android.support.v4.app.Fragment  implements
LoaderManager.LoaderCallbacks<Cursor>{
	private ListView nearList;
	private static final int LOADER_ID = 0x01;
	private CursorAdapter adapter;
	 
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		nearList = (ListView) inflater.inflate(R.layout.near_list_fragment_layout, null);
		
		//nearList.setAdapter(new ArrayAdapter<String>(getActivity(), android.R.layout.simple_list_item_1, new String[]{"1","1","1","1","1","1","1","1","1","1"}));
		//Cursor c = getActivity().getContentResolver().query(MediaContentProvider.PLACES_URI, null, null, null, null);
		//getActivity().startManagingCursor(c);
		getActivity().getSupportLoaderManager().initLoader(LOADER_ID, null, this);
		//nearList.setAdapter(new PlacesAdapter(getActivity(), c));
		/*nearList.setAdapter(new BaseAdapter() {
			
			@Override
			public View getView(int position, View convertView, ViewGroup parent) {
				if(convertView == null){
					convertView = LayoutInflater.from(getActivity()).inflate(R.layout.near_list_item, null);
				}
				return convertView;
			}
			
			@Override
			public long getItemId(int position) {
				return position;
			}
			
			@Override
			public Object getItem(int position) {
				return position;
			}
			
			@Override
			public int getCount() {
				return 15;
			}
		});*/
		return nearList;
	}
	private class PlacesAdapter extends CursorAdapter{

		public PlacesAdapter(Context context, Cursor c) {
			super(context, c);
		}

		private final String imagesPath = Environment.getExternalStorageDirectory() + "/BSGDemo/"; 
		@Override
		public void bindView(View arg0, Context arg1, Cursor arg2) {
			Place p = new Place(arg2);
			((TextView)arg0.findViewById(R.id.paces_item_title)).setText(p.getTitle());
			((ImageView)arg0.findViewById(R.id.icon)).setImageBitmap(BitmapFactory.decodeFile(imagesPath + p.getIconPath()));
			//((Button)arg0.findViewById(R.id.places_item_position)).setText(p.getId());
		}

		@Override
		public View newView(Context arg0, Cursor arg1, ViewGroup arg2) {
			View rootView = LayoutInflater.from(arg0).inflate(R.layout.near_list_item, null);
			//bindView(rootView, arg0, arg1);
			return rootView;
		}
	}
	@Override
	public Loader<Cursor> onCreateLoader(int arg0, Bundle arg1) {
		 return new CursorLoader(getActivity(), MediaContentProvider.PLACES_URI, null, null, null, null);
	}
	@Override
	public void onLoadFinished(Loader<Cursor> arg0, Cursor arg1) {
		adapter = new PlacesAdapter(getActivity(), arg1);
		nearList.setAdapter(adapter);
		nearList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
					long arg3) {
				Intent target = new Intent(getActivity(), PlaceDescriptionActivity.class); 
				target.putExtra("id", arg3);
				startActivity(target);
			}
		});
		//adapter.swapCursor(arg1);
	}
	@Override
	public void onLoaderReset(Loader<Cursor> arg0) {
		 adapter.swapCursor(null);
	}
}